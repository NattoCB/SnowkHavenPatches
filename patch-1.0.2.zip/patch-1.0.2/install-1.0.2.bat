@echo off
setlocal

set "PATCH_ROOT=%~dp0"
pushd "%PATCH_ROOT%\.." >nul

if not exist ".minecraft\mods" (
    echo Missing .minecraft\mods directory
    popd >nul
    exit /b 1
)

echo Installing patch 1.0.2...

copy /Y "%PATCH_ROOT%patch\CustomSkinLoader_ForgeV2-14.28.jar" ".minecraft\mods\CustomSkinLoader_ForgeV2-14.28.jar" >nul || goto :copy_failed
echo Added CustomSkinLoader_ForgeV2-14.28.jar

copy /Y "%PATCH_ROOT%patch\IMBlocker-5.5.3-forge+1.17-1.20.4.jar" ".minecraft\mods\IMBlocker-5.5.3-forge+1.17-1.20.4.jar" >nul || goto :copy_failed
echo Added IMBlocker-5.5.3-forge+1.17-1.20.4.jar

copy /Y "%PATCH_ROOT%patch\SnowkCoreMod-1.1-1.20.1-forge.jar" ".minecraft\mods\SnowkCoreMod-1.1-1.20.1-forge.jar" >nul || goto :copy_failed
echo Replaced SnowkCoreMod-1.1-1.20.1-forge.jar

if exist ".minecraft\snowk1-0-2.version" del /Q ".minecraft\snowk1-0-2.version"
> ".minecraft\snowk1-0-2.version" echo 1.0.2
echo Updated client marker to snowk1-0-2.version

popd >nul
exit /b 0

:copy_failed
echo Failed to copy patch files
popd >nul
exit /b 1
