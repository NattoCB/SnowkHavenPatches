@echo off
setlocal

set "PATCH_ROOT=%~dp0"
pushd "%PATCH_ROOT%\.." >nul

if not exist ".minecraft\mods" (
    echo Missing .minecraft\mods directory
    popd >nul
    exit /b 1
)

echo Installing patch 1.0.3...

if exist ".minecraft\mods\moonlight-1.20-2.16.30-forge.jar" (
    del /Q ".minecraft\mods\moonlight-1.20-2.16.30-forge.jar" || goto :delete_failed
    echo Removed moonlight-1.20-2.16.30-forge.jar
) else (
    echo moonlight-1.20-2.16.30-forge.jar already absent
)

if exist ".minecraft\mods\supplementaries-1.20-3.1.43-forge.jar" (
    del /Q ".minecraft\mods\supplementaries-1.20-3.1.43-forge.jar" || goto :delete_failed
    echo Removed supplementaries-1.20-3.1.43-forge.jar
) else (
    echo supplementaries-1.20-3.1.43-forge.jar already absent
)

if exist ".minecraft\snowk1-0-3.version" del /Q ".minecraft\snowk1-0-3.version"
> ".minecraft\snowk1-0-3.version" echo 1.0.3
echo Updated client marker to snowk1-0-3.version

popd >nul
exit /b 0

:delete_failed
echo Failed to delete patch files
popd >nul
exit /b 1
